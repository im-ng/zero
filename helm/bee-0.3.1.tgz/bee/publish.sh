#!/bin/bash
curl --user ng:1bf077a04f54e3353ad419693bf965cc35916276 \
     -X POST --upload-file ./bee-0.2.0.tgz \
     https://gitea.pi/api/packages/ng/helm/api/charts
