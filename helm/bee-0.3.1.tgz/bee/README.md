# Bee — Zero Framework Application Helm Chart

Helm chart for deploying **Zero** framework (Zig) applications on Kubernetes.

Chart `version: 0.2.0` targets Zero `appVersion: 0.16.0`

## Quickstart

```bash
# Generate manifests (dry-run)
helm template my-release . -f values-override.yaml > manifest.yaml

# Deploy directly
helm upgrade --install my-release . -f values-override.yaml

# Generate + apply
helm template my-release . -f values-override.yaml | kubectl apply -f -

# Package bee chart
helm package --version 0.3.0 --app-version 1.0.0 .
```

- Object names are derived from `app.name` / `nameOverride` (no release prefix).
- For the basic example, every object is named `zero-basic` (Deployment, Service, Ingress,
  ServiceMonitor).
- Alerts render a rule ConfigMap `prometheus-rules-zero-basic` in the
  `monitoring` namespace, which the standalone Prometheus mounts and evaluates.

## values.yaml reference

| Key                       | Type   | Default               | Description                                           |
| ------------------------- | ------ | --------------------- | ----------------------------------------------------- |
| `namespace`               | string | `default`             | Namespace for all generated objects                   |
| `app.name`                | string | `zero-app`            | App name (object names, labels, image repo fallback)  |
| `app.version`             | string | `0.16.0`              | App version (also chart appVersion)                   |
| `app.logLevel`            | string | `INFO`                | Zero log level (DEBUG/INFO/WARN/ERROR)                |
| `app.logFormat`           | string | `json`                | Log format: `text` or `json` (zero 0.16 structured)   |
| `app.logTimezone`         | string | `UTC`                 | Log tz: `local` or IANA tz (e.g. `Asia/Kolkata`)      |
| `app.authMode`            | string | `""`                  | Inbound auth: `/Basic/APIKey/OAuth`                   |
| `app.healthPath`          | string | `/.well-known/health` | Liveness/readiness/startup probe path                 |
| `app.metricsPath`         | string | `/metrics`            | Prometheus metrics scrape path                        |
| `app.port`                | int    | `8000`                | HTTP container port                                   |
| `app.metricsPort`         | int    | `2121`                | Metrics container port                                |
| `image.registry`          | string | `registry.pi`         | Image registry                                        |
| `image.repository`        | string | `""`                  | Image repo (falls back to `app.name`)                 |
| `image.tag`               | string | `""`                  | Image tag (falls back to `app.version`)               |
| `image.pullPolicy`        | string | `IfNotPresent`        | Image pull policy                                     |
| `replicaCount`            | int    | `1`                   | Number of replicas                                    |
| `strategy.type`           | string | `RollingUpdate`       | Deployment strategy                                   |
| `env`                     | map    | `{}`                  | Plain env vars (key: value)                           |
| `secretEnv`               | list   | `[]`                  | Individual env vars from Secret keys                  |
| `configMapEnv`            | list   | `[]`                  | Individual env vars from ConfigMap keys               |
| `envFromSecrets`          | list   | `[]`                  | Bulk-load all keys from Secrets                       |
| `envFromConfigMaps`       | list   | `[]`                  | Bulk-load all keys from ConfigMaps                    |
| `configMap`               | map    | `{}`                  | Create and embed a ConfigMap (`<name>-cm`)            |
| `secret`                  | map    | `{}`                  | Create and embed a Secret (`<name>-secret`)           |
| `volumeMounts`            | list   | `[]`                  | Container volume mounts                               |
| `volumes`                 | list   | `[]`                  | Pod-level volumes                                     |
| `resources`               | map    | (see values.yaml)     | Resource requests/limits                              |
| `service.type`            | string | `ClusterIP`           | Service type                                          |
| `service.annotations`     | map    | `{}`                  | Service annotations                                   |
| `service.labels`          | map    | `{}`                  | Additional service labels                             |
| `ingress.enabled`         | bool   | `false`               | Enable ingress                                        |
| `ingress.host`            | string | `zero-app.local`      | Ingress hostname                                      |
| `ingress.tls.enabled`     | bool   | `false`               | Enable TLS                                            |
| `ingress.tls.secretName`  | string | `""`                  | TLS secret name                                       |
| `podLabels`               | map    | `{}`                  | Additional pod labels                                 |
| `podAnnotations`          | map    | `{}`                  | Pod annotations                                       |
| `securityContext`         | map    | `{}`                  | Container security context                            |
| `podSecurityContext`      | map    | `{}`                  | Pod security context                                  |
| `serviceAccount.create`   | bool   | `true`                | Create service account                                |
| `nodeAffinity.required`   | string | `""`                  | Required worker node label                            |
| `nodeAffinity.preferred`  | string | `""`                  | Preferred worker node label                           |
| `serviceMonitor.enabled`  | bool   | `false`               | Enable Prometheus ServiceMonitor                      |
| `serviceMonitor.interval` | string | `15s`                 | Scrape interval                                       |
| `alerts.enabled`          | bool   | `false`               | Render alert rule ConfigMap for standalone Prometheus |
| `alerts.namespace`        | string | `monitoring`          | Namespace for the rule ConfigMap                      |
| `alerts.groups`           | list   | `[]`                  | Alert rule groups                                     |
| `autoscaling.enabled`     | bool   | `false`               | Enable HPA                                            |

## Environment variable injection

Three mechanisms (applied in order, `env` overrides `envFrom`):

### 1. Bulk-load (envFrom)

Embedded `configMap` / `secret` are named from `nameOverride` and auto-loaded —
no manual names to repeat:

```yaml
nameOverride: zero

configMap:
  enabled: true
  data:
    HTTP_PORT: "8000"
    LOG_LEVEL: "INFO"

secret:
  enabled: true
  stringData:
    client_id: ...
```

This renders `envFrom: - configMapRef: {name: zero}, - secretRef: {name: zerocret}`.

External ConfigMaps/Secrets can still be bulk-loaded by name:

```yaml
envFromSecrets:
  - name: db-credentials

envFromConfigMaps:
  - name: shared-config
```

### 2. Individual key-value (env)

```yaml
env:
  APP_NAME: zero
  LOG_LEVEL: DEBUG
```

### 3. Individual secret/configmap key references

```yaml
secretEnv:
  - name: DHAN_CLIENT_ID
    secretName: zerocret
    key: client_id
```

## Embed ConfigMaps and Secrets

Names are derived from `nameOverride` (`<nameOverride>-cm`, `<nameOverride>-secret`),
so there is a single source of truth:

```yaml
nameOverride: zero

configMap:
  enabled: true
  data:
    HTTP_PORT: "8000"
    LOG_LEVEL: "INFO"

secret:
  enabled: true
  type: Opaque
  stringData:
    client_id: your-dhan-client-id
    access_token: your-dhan-access-token
```

Each becomes a `ConfigMap` / `Secret` manifest and its keys are automatically
loaded into the container via `envFrom` — no `envFromConfigMaps`/`envFromSecrets`
entry needed for the embedded resources.

## Attach an existing PVC

```yaml
volumeMounts:
  - name: flowy-storage
    mountPath: /app/data

volumes:
  - name: flowy-storage
    persistentVolumeClaim:
      claimName: flowy-local-pvc
```

## Prometheus alerts

Renders a `v1 ConfigMap` named `prometheus-rules-<app>` in `monitoring` (not a
PrometheusRule CR — this cluster runs standalone Prometheus, not the operator).
Add the ConfigMap as a volume in `k8s/prometheus/prom/prometheus-deployment.yaml`
once per app:

```yaml
# values-override.yaml
alerts:
  enabled: true
  namespace: monitoring
  labels:
    app: zero
  groups:
    - name: zero
      rules:
        - alert: zeron
          expr: up{job="zero== 0
          for: 5m
          labels:
            severity: critical
          annotations:
            summary: "zerorvice is down"
```

```yaml
# prometheus-deployment.yaml (one-time per app)
#   volumeMounts:
#   - name: rules-zero
#     mountPath: /etc/prometheus/rules/zero
#   volumes:
#   - name: rules-zero
#     configMap:
#       name: prometheus-rules-zero
```

## Prometheus ServiceMonitor

```yaml
serviceMonitor:
  enabled: true
  interval: 15s
  labels:
    app: zero
    team: zero
```

## Node affinity

For k3s clusters with labeled workers:

```yaml
nodeAffinity:
  required: south # required node label worker=south
  preferred: north # preferred node label worker=north
```

## Full example

See `values-override.yaml` for the zeroample, and `values-zero-0.16.yaml` for a
complete **zero 0.16** example that exercises the new configuration surface
(RATE*LIMIT*_, ZERO*HTTP_LARGE_BUFFER*_, S3*\*, SQLITE*_, SERVICE*<NAME>*_, JSON
logging, inbound auth, circuit breaker, etc.).

## Health, metrics & probes (zero 0.16)

Zero 0.16 serves its liveness endpoint at **`/.well-known/health`** (not `/health`).
The chart hardcodes that default in `app.healthPath` and wires it into the
`livenessProbe`, `readinessProbe`, and a `startupProbe` (the latter tolerates slow
boots such as DB migrations). Metrics are scraped from `app.metricsPort` at
`app.metricsPath` (default `/metrics`); the ServiceMonitor path falls back to
`app.metricsPath` when `serviceMonitor.path` is empty.

## Resource sizing (zero 0.16)

PR #9 decoupled the httpz buffer pool, dropping steady-state RSS to **~16–65 MiB**.
The chart default requests are therefore `cpu: 100m / memory: 64Mi` (limits
`500m / 256Mi`). Scale requests up if you enable large SQLite/S3 workloads.

## Zero 0.16 config reference

All keys shown in `values-zero-0.16.yaml` mirror `config.md` in the framework repo:
logging (`LOG_FORMAT`, `ZERO_LOG_TIMEZONE`), HTTP/runtime (`ZERO_REQUEST_TIMEOUT_MS`,
`INBOUND_MAX_CONCURRENT`, `ZERO_HTTP_LARGE_BUFFER_*`), inbound rate limiting
(`RATE_LIMIT_*`), datasources (`DB_*`, `REDIS_*`, `SQLITE_*`, `S3_*`,
`FILE_STORE_*`), and outbound service clients (`SERVICE_<NAME>_*`).
