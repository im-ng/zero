{{- define "bee.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "bee.fullname" -}}
{{- $name := .Values.nameOverride | default .Values.app.name | default .Chart.Name }}
{{- $name | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "bee.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "bee.labels" -}}
helm.sh/chart: {{ include "bee.chart" . }}
{{ include "bee.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{- define "bee.selectorLabels" -}}
app.kubernetes.io/name: {{ include "bee.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{- define "bee.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "bee.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{- define "bee.appName" -}}
{{- .Values.app.name | default (include "bee.name" .) }}
{{- end }}

{{- define "bee.appVersion" -}}
{{- .Values.app.version | default .Chart.AppVersion }}
{{- end }}

{{- define "bee.image" -}}
{{- $registry := .Values.image.registry | default "docker.io" }}
{{- $repository := .Values.image.repository | default .Values.app.name }}
{{- $tag := .Values.image.tag | default (include "bee.appVersion" .) }}
{{- printf "%s/%s:%s" $registry $repository $tag }}
{{- end }}

{{- define "bee.namespace" -}}
{{- .Values.namespace | default .Release.Namespace }}
{{- end }}

{{- define "bee.configMapName" -}}
{{- printf "%s-cm" (include "bee.fullname" .) | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "bee.secretName" -}}
{{- printf "%s-secret" (include "bee.fullname" .) | trunc 63 | trimSuffix "-" }}
{{- end }}
